#include <stdio.h>
typedef int (*funcp) ();
funcp peqcomp(FILE *f, unsigned char codigo[]);